#ifndef AIR_SENSOR_H
#define AIR_SENSOR_H

//Own libraries
#include "main.h"

void initAir();
void updateAir(Info *air);

#endif