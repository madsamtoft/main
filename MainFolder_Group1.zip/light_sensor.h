#ifndef LIGHT_SENSOR_H
#define LIGHT_SENSOR_H

//Own libraries
#include "main.h"

void initLight();
void updateLight(Info *light);

#endif